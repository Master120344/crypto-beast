extern char **codecs;

int codec_supported (int flags);
